<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
    <link rel="stylesheet" type="text/CSS" href="CSS/Betaling.css">
</head>

<body>
    <h1>Doneer een getal boven de nul</h1>
    <a href="doneer.php"><button>Ga Terug</button></a>
</body>

</html>