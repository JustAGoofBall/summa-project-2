<?php
include 'php/connection.php';

$input = [];
$statement1 = $conn->query("SELECT Voornaam, Achternaam, Bedrag FROM donatietabel ORDER BY Bedrag DESC LIMIT 5");
$input = $statement1->fetchAll(PDO::FETCH_ASSOC);

// Haal de meest recente donaties op
$statement2 = $conn->query("SELECT Voornaam, Achternaam, Bedrag FROM donatietabel ORDER BY DonatieDatum	 DESC LIMIT 5");
$input_recent = $statement2->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['Voornaam'])) {
        $voornaam = $_POST['Voornaam'];
    }

    if (isset($_POST['Achternaam'])) {
        $achternaam = $_POST['Achternaam'];
    }

    if (isset($_POST['Bedrag'])) {
        $bedrag = $_POST['Bedrag'];
        echo "<h1>hallo</h1>";
    }

    if ($bedrag > 0) {
        $query = "SELECT Bedrag FROM donatietabel WHERE Voornaam = :voornaam AND Achternaam = :achternaam";
        $statement = $conn->prepare($query);
        $statement->bindParam(':voornaam', $voornaam);
        $statement->bindParam(':achternaam', $achternaam);
        $statement->execute();
        $existingDonation = $statement->fetch(PDO::FETCH_ASSOC);

        if ($existingDonation) {
            $bedrag += $existingDonation['Bedrag'];
            $updateQuery = "UPDATE donatietabel SET Bedrag = :bedrag WHERE Voornaam = :voornaam AND Achternaam = :achternaam";
            $updateStatement = $conn->prepare($updateQuery);
            $updateStatement->bindParam(':bedrag', $bedrag);
            $updateStatement->bindParam(':voornaam', $voornaam);
            $updateStatement->bindParam(':achternaam', $achternaam);
            $updateStatement->execute();
        } else {
            $insertQuery = "INSERT INTO donatietabel (Achternaam, Bedrag, Voornaam) VALUES (:achternaam, :bedrag, :voornaam)";
            $insertStatement = $conn->prepare($insertQuery);
            $insertStatement->bindParam(':achternaam', $achternaam);
            $insertStatement->bindParam(':bedrag', $bedrag);
            $insertStatement->bindParam(':voornaam', $voornaam);
            $insertStatement->execute();
        }
    }
}

if (isset($_POST['submit'])) {
    if ($bedrag > 0) {
        header('location: IsGelukt.php');
    } else {
        header('location: Error.php');
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>doneer</title>
    <link rel="stylesheet" type="text/CSS" href="CSS/alles.css">
    <link rel="stylesheet" type="text/CSS" href="CSS/doneer.css">
    <script src="JS/Alles.js"></script>
    <script src="https://kit.fontawesome.com/a4d79bb58d.js" crossorigin="anonymous"></script>
</head>

<body id="body">
    <header>
        <a href="home.php"><img src="Img/GroenLinks_logo.png" alt="" class="logo"></a>
        <nav>
            <input type="checkbox" id="check" onchange='handleChange(this);'>
            <label for="check" class="checkbtn">
                <i class="fas fa-bars"></i>
            </label>
            <ul>
                <li><a href="standpunten.php" class="active">Standpunten</a></li>
                <li><a href="leden.php">Onze leden</a></li>
                <li><a href="doneer.php">Doneer</a></li>
                <li><a href="contact_us.php">Contact us</a></li>
                <li><a href="uitloggen.php">Uitloggen</a></li>
                <li><a href="profiel.php"><i class="fa-solid fa-user"></i></a></li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="container4">
            <div class="Img1">
                <img src="Img/protest_3man.jpg" alt="">
            </div>
            <div>
                <h1>DONEER AAN GROENLINKS</h1>
                <form method="POST" action="doneer.php" id="Form2">
                    <label for="Voornaam">Voornaam</label>
                    <input type="text" name="Voornaam" id="Voornaam" required>
                    <label for="Achternaam">Achternaam</label>
                    <input type="text" name="Achternaam" id="Achternaam" required>
                    <label for="Bedrag">Bedrag</label>
                    <input type="number" name="Bedrag" id="Bedrag" required>
                    <br>
                    <input type="submit" class="btn" name="submit">
                    <br>
                </form>
                <div class="Donators">
                    <h2>TOP 5 DONATORS</h2>
                </div>
                <div class="container6">
                    <table class="myTable">
                        <thead>
                            <tr>
                                <th>Naam</th>
                                <th>Bedrag</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($input as $inputs) : ?>
                                <tr>
                                    <td><?php echo $inputs['Voornaam'], ' ', $inputs['Achternaam']; ?></td>
                                    <td><?php echo '€', $inputs['Bedrag'], ',-'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div><br>
                <div class="Donators">
                    <h2>Meest recente donaties</h2>
                </div>
                <div class="container6">
                    <table class="myTable">
                        <thead>
                            <tr>
                                <th>Naam</th>
                                <th>Bedrag</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($input_recent as $input) : ?>
                                <tr>
                                    <td><?php echo $input['Voornaam'], ' ', $input['Achternaam']; ?></td>
                                    <td><?php echo '€', $input['Bedrag'], ',-'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    <footer>
        <h2>Volg ons op social media!</h2>
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-linkedin-in"></i></a>
    </footer>
</body>

</html>